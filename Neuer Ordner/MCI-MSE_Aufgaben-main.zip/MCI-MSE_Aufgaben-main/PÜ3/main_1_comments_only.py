# UC 2.0

#%% UC 2.1 Einlesen der Daten

## Überprüfen ob Dateien vorhanden sind


## Erstellen einer Liste von Tests, die zu verarbeiten sind


#%% UC 2.2 Vorverarbeiten der Daten

## Anlegen einer Zeitreihe der Herzfrequenz aus den EKG-Daten

#%% UC 2.3 Analysieren der Daten auf Abbruch-Kriterium

## Vergleich der Maximalen Herzfrequenz mit Alter des Patienten

#%% UC 2.4 Erstellen einer Zusammenfassung

## Ausgabe einer Zusammenfassung

#%% UC 2.5 Visualisierung der Daten

## Erstellung eines Plots

#%% UC 2.6 Manuelle Eingabe eines Abbruchkritierums

## Abfrage an Nutzer:in, ob Abgebrochen werden soll

#%% UC 2.7 Speichern der Daten

# Speichern der Daten